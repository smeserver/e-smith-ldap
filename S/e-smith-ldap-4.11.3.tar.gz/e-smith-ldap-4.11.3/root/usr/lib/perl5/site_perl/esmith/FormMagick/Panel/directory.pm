#!/usr/bin/perl -w 

#
# $Id: directory.pm,v 1.3 2003/12/18 17:19:54 msoulier Exp $
#

package esmith::FormMagick::Panel::directory;

use strict;
use esmith::AccountsDB;
use esmith::ConfigDB;
use esmith::FormMagick;
use esmith::util;
use File::Basename;
use Exporter;
use Carp;

our @ISA = qw(esmith::FormMagick Exporter);

our @EXPORT = qw( 
    get_ldap_base  get_value get_prop change_settings
);

our $VERSION = sprintf '%d.%03d', q$Revision: 1.3 $ =~ /: (\d+).(\d+)/;

our $db = esmith::ConfigDB->open();


# {{{ header

=pod 

=head1 NAME

esmith::FormMagick::Panels::directory - useful panel functions

=head1 SYNOPSIS

    use esmith::FormMagick::Panels::directory;

    my $panel = esmith::FormMagick::Panel::directory->new();
    $panel->display();

=head1 DESCRIPTION

=cut

# }}}

# {{{ new

=head2 new();

Exactly as for esmith::FormMagick

=begin testing


use_ok('esmith::FormMagick::Panel::directory');
use vars qw($panel);
ok($panel = esmith::FormMagick::Panel::directory->new(), "Create panel object");
isa_ok($panel, 'esmith::FormMagick::Panel::directory');

=end testing

=cut



sub new {
    shift;
    my $self = esmith::FormMagick->new();
    $self->{calling_package} = (caller)[0];
    bless $self;
    return $self;
}

# }}}

# {{{ get_prop

=head2 get_prop ITEM PROP

A simple accessor for esmith::ConfigDB::Record::prop

=cut

sub get_prop {
  my $fm = shift;
  my $item = shift;
  my $prop = shift;

  my $record = $db->get($item);
  if ($record) {
    return $record->prop($prop);
  }
  else {
    return '';
  }

}

# }}}

=head2 get_ldap_base

Gets the LDAP base for this domain

=cut

sub get_ldap_base {
    return esmith::util::ldapBase(get_value('','DomainName'));
}


# {{{ get_value 

=head2 get_value ITEM

A simple accessor for esmith::ConfigDB::Record::value

=cut

sub get_value {
    my $fm = shift;
    my $item = shift;

    my $record = $db->get($item);
    if ($record) {
        return $record->value();
    }
    else {
        return '';
    }
}

# }}}

=head1 ACTION


# {{{ change_settings

=head2 change_settings

If everything has been validated, properly, go ahead and set the new settings

=cut



sub change_settings {
    my ($fm) = @_;

    my $q = $fm->{'cgi'};

    my $access = $q->param ('Access') || 'private';
    my $department = $q->param ('Department') || "";
    my $company = $q->param ('Company') || "";
    my $street = $q->param ('Street') || "";
    my $city = $q->param ('City') || "";
    my $phone = $q->param ('PhoneNumber') || "";
    my $existing = $q->param ('Existing') || 'leave' ;
    $db->get('ldap')->set_prop('access', $access);
    $db->get('ldap')->set_prop('defaultDepartment', $department);
    $db->get('ldap')->set_prop('defaultCompany', $company);
    $db->get('ldap')->set_prop('defaultStreet', $street);
    $db->get('ldap')->set_prop('defaultCity', $city);
    $db->get('ldap')->set_prop('defaultPhoneNumber', $phone);

    #------------------------------------------------------------
    # If requested, update the account records for all existing users.
    # Don't need to signal any special events for this, since we're only
    # changing LDAP information. If we were changing the user names
    # or email parameters, we'd have to signal events to trigger the
    # right updates.
    #------------------------------------------------------------

    if ($existing eq 'update') {
        my $a = esmith::AccountsDB->open;
        my @users    = $a->users();

        foreach my $user (@users) {
            $user->set_prop('Phone', $phone);
            $user->set_prop('Company', $company);
            $user->set_prop('Dept', $department);
            $user->set_prop('City', $city);
            $user->set_prop('Street', $street);

        }
    }
    #------------------------------------------------------------
    # Update the system
    #------------------------------------------------------------

    system ("/sbin/e-smith/signal-event ldap-update") == 0
        or die ("Error occurred while updating system configuration.\n");

    $fm->{cgi}->param( -name => 'wherenext', -value => 'Done' );
}

# }}}

1;
